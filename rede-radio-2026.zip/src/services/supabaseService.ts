import { supabase } from '../supabase';

export const supabaseService = {
  // Clients
  async getClients(ownerId: string) {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('owner_id', ownerId)
      .order('razao_social', { ascending: true });
    
    if (error) throw error;
    return data;
  },

  async saveClient(client: any, ownerId: string) {
    const { data, error } = await supabase
      .from('clients')
      .upsert({
        ...client,
        owner_id: ownerId,
        updated_at: new Date().toISOString()
      }, { onConflict: 'documento, owner_id' }) // Example conflict resolution
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteClient(id: string) {
    const { error } = await supabase
      .from('clients')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // PIs
  async getPIs(ownerId: string) {
    const { data, error } = await supabase
      .from('pis')
      .select('*, clients(*)')
      .eq('owner_id', ownerId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async savePI(pi: any, ownerId: string) {
    const { data, error } = await supabase
      .from('pis')
      .insert({
        ...pi,
        owner_id: ownerId
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Interactions
  async getInteractions(ownerId: string) {
    const { data, error } = await supabase
      .from('interactions')
      .select('*, clients(*)')
      .eq('owner_id', ownerId)
      .order('date', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async saveInteraction(interaction: any, ownerId: string) {
    const { data, error } = await supabase
      .from('interactions')
      .insert({
        ...interaction,
        owner_id: ownerId
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};
