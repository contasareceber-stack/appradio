// 2026 REDE DE RADIO COMUNICAÇÃO
import React, { useState, useRef, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import SignaturePad from 'react-signature-canvas';
import { 
  FileText, 
  FileSpreadsheet, 
  Download, 
  Plus, 
  Save,
  Trash2, 
  Building2, 
  Calendar, 
  Clock, 
  DollarSign,
  CheckCircle2,
  AlertCircle,
  Loader2,
  User,
  LogOut,
  LogIn,
  Search,
  Edit2,
  LayoutDashboard,
  Users,
  History,
  TrendingUp,
  MessageSquare,
  Phone,
  Mail,
  MoreVertical
} from 'lucide-react';
import { format, differenceInDays, parseISO, addMonths, setDate } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { supabase } from './supabase';
import { supabaseService } from './services/supabaseService';

const AuthView = ({ onLogin }: { onLogin: (provider: 'google' | 'github') => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        alert('Verifique seu e-mail para confirmar o cadastro!');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!email) {
      setError('Por favor, insira seu e-mail para redefinir a senha.');
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) throw error;
      setResetSent(true);
      setError('');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-100 p-10"
      >
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white shadow-lg shadow-indigo-200 mx-auto mb-6">
            <Building2 size={40} />
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-2">
            {isLogin ? 'Bem-vindo de volta' : 'Crie sua conta'}
          </h2>
          <p className="text-sm text-slate-500 font-medium">
            {isLogin ? 'Acesse sua conta para gerenciar seus PIs' : 'Comece a gerenciar seus PIs hoje mesmo'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium text-sm"
                placeholder="seu@email.com"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Senha</label>
            <div className="relative">
              <LogIn className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium text-sm"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-xs font-bold">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          {resetSent && (
            <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-3 text-emerald-600 text-xs font-bold">
              <CheckCircle2 size={16} />
              E-mail de redefinição enviado!
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : (isLogin ? 'Entrar' : 'Cadastrar')}
          </button>
        </form>

        <div className="mt-8 space-y-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-slate-100"></span>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest">
              <span className="bg-white px-4 text-slate-400">Ou continue com</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => onLogin('google')}
              className="py-4 bg-white border-2 border-slate-100 text-slate-700 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:border-indigo-600 hover:text-indigo-600 transition-all flex items-center justify-center gap-2"
            >
              <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" />
              Google
            </button>
            <button
              onClick={() => onLogin('github')}
              className="py-4 bg-white border-2 border-slate-100 text-slate-700 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:border-indigo-600 hover:text-indigo-600 transition-all flex items-center justify-center gap-2"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
              </svg>
              GitHub
            </button>
          </div>
        </div>

        <div className="mt-10 text-center space-y-2">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
          >
            {isLogin ? 'Não tem uma conta? Cadastre-se' : 'Já tem uma conta? Faça login'}
          </button>
          {isLogin && (
            <div className="block">
              <button
                onClick={handleResetPassword}
                className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-indigo-600 transition-colors"
              >
                Esqueceu a senha?
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

const DashboardView = ({ pis, clients, interactions, onNewPI, onAddInteraction }: any) => {
  const totalRevenue = pis.reduce((acc: number, pi: any) => acc + (pi.valorTotal || 0), 0);
  const activeClients = clients.length;
  const pendingPis = pis.filter((pi: any) => pi.status === 'SENT').length;

  return (
    <div className="space-y-8">
      {/* ... stats ... */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl group-hover:scale-110 transition-transform">
              <TrendingUp size={24} />
            </div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Receita Total</h3>
          </div>
          <p className="text-3xl font-black text-slate-900 tracking-tight">
            R$ {totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:scale-110 transition-transform">
              <Users size={24} />
            </div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Clientes Ativos</h3>
          </div>
          <p className="text-3xl font-black text-slate-900 tracking-tight">{activeClients}</p>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl group-hover:scale-110 transition-transform">
              <Clock size={24} />
            </div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">PIs Pendentes</h3>
          </div>
          <p className="text-3xl font-black text-slate-900 tracking-tight">{pendingPis}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-3">
              <History className="text-indigo-600" size={20} />
              Últimos Pedidos (PIs)
            </h3>
            <button onClick={() => {}} className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">
              Ver todos
            </button>
          </div>
          <div className="space-y-4">
            {pis.slice(0, 5).map((pi: any) => (
              <div key={pi.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-indigo-100 transition-colors">
                <div>
                  <p className="text-sm font-bold text-slate-900">{pi.clientName}</p>
                  <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">{pi.emissora} • {pi.dataInicio}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black text-slate-900">R$ {pi.valorTotal?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                  <span className={cn(
                    "text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full",
                    pi.status === 'PAID' ? "bg-emerald-100 text-emerald-600" : "bg-amber-100 text-amber-600"
                  )}>
                    {pi.status}
                  </span>
                </div>
              </div>
            ))}
            {pis.length === 0 && (
              <div className="text-center py-12">
                <FileText className="mx-auto text-slate-200 mb-4" size={48} />
                <p className="text-sm text-slate-400 font-medium">Nenhum pedido gerado ainda.</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-3">
              <MessageSquare className="text-indigo-600" size={20} />
              Interações Recentes
            </h3>
            <button 
              onClick={onAddInteraction}
              className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
            >
              Nova Nota
            </button>
          </div>
          <div className="space-y-4">
            {interactions.slice(0, 5).map((int: any) => (
              <div key={int.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-3 mb-2">
                  <span className="p-1.5 bg-white rounded-lg shadow-sm">
                    {int.type === 'CALL' && <Phone size={12} className="text-indigo-600" />}
                    {int.type === 'EMAIL' && <Mail size={12} className="text-indigo-600" />}
                    {int.type === 'MEETING' && <Users size={12} className="text-indigo-600" />}
                    {int.type === 'NOTE' && <FileText size={12} className="text-indigo-600" />}
                  </span>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    {int.type} • {int.date}
                  </p>
                </div>
                <p className="text-sm text-slate-700 font-medium leading-relaxed">{int.description}</p>
              </div>
            ))}
            {interactions.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="mx-auto text-slate-200 mb-4" size={48} />
                <p className="text-sm text-slate-400 font-medium">Nenhuma interação registrada.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const ClientsView = ({ clients, onLoadClient, onDeleteClient }: any) => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
          <Users className="text-indigo-600" size={28} />
          Gestão de Clientes
        </h3>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar cliente..." 
            className="pl-12 pr-6 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none w-64 transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {clients.map((client: any) => (
          <div key={client.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-indigo-500/10 transition-colors" />
            
            <div className="flex justify-between items-start mb-6 relative z-10">
              <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
                <Building2 size={24} />
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => onLoadClient(client)}
                  className="p-2 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded-xl transition-colors"
                >
                  <Edit2 size={18} />
                </button>
                <button 
                  onClick={() => onDeleteClient(client.id)}
                  className="p-2 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>

            <div className="relative z-10">
              <h4 className="text-lg font-black text-slate-900 mb-1 line-clamp-1">{client.razaoSocial}</h4>
              <p className="text-xs text-slate-500 font-medium mb-6 uppercase tracking-wider">{client.nomeFantasia || 'Sem Nome Fantasia'}</p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-xs text-slate-600 font-medium">
                  <FileText size={14} className="text-slate-400" />
                  {client.documento}
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-600 font-medium">
                  <Mail size={14} className="text-slate-400" />
                  {client.email1}
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-600 font-medium">
                  <Phone size={14} className="text-slate-400" />
                  {client.contato1}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-50 flex justify-between items-center relative z-10">
              <div className="flex -space-x-2">
                <div className="w-8 h-8 rounded-full bg-indigo-100 border-2 border-white flex items-center justify-center text-[10px] font-black text-indigo-600">PI</div>
                <div className="w-8 h-8 rounded-full bg-emerald-100 border-2 border-white flex items-center justify-center text-[10px] font-black text-emerald-600">CT</div>
              </div>
              <button 
                onClick={() => onLoadClient(client)}
                className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
              >
                Novo Pedido
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const FIXED_DATA = {
  razaoSocial: "REDE DE RADIO COMUNICAÇÃO",
  endereco: "Endereço a definir",
  cnpj: "00.000.000/0000-00",
  inscricaoEstadual: "Isento"
};

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Produto {
  id: string;
  tipo: string;
  periodicidade: string;
  quantidade: string;
  valorUnitario: string;
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [savedClients, setSavedClients] = useState<any[]>([]);
  const [showClientList, setShowClientList] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [clientData, setClientData] = useState({
    razaoSocial: '',
    nomeFantasia: '',
    documento: '', // CNPJ ou CPF
    endereco: '',
    cep: '',
    inscricaoEstadual: '',
    contato1: '',
    contato2: '',
    email1: '',
    email2: '',
    dataInicio: '',
    dataFim: '',
    tipoGrade: 'DETERMINADO',
    gradeHorarios: '',
    emissora: '',
    diaPagamento: '',
    desconto: '0',
    produtos: [{ id: crypto.randomUUID(), tipo: '', periodicidade: '', quantidade: '', valorUnitario: '' }] as Produto[],
  });

  const [isGenerated, setIsGenerated] = useState(false);
  const [view, setView] = useState<'dashboard' | 'pi-generator' | 'clients'>('dashboard');
  const [pis, setPis] = useState<any[]>([]);
  const [interactions, setInteractions] = useState<any[]>([]);
  const [showInteractionModal, setShowInteractionModal] = useState(false);
  const [newInteraction, setNewInteraction] = useState({
    clientId: '',
    type: 'NOTE',
    description: '',
    date: format(new Date(), 'yyyy-MM-dd')
  });
  const [loadingCep, setLoadingCep] = useState(false);
  const [loadingCnpj, setLoadingCnpj] = useState(false);
  const [cnpjError, setCnpjError] = useState<string | null>(null);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const sigPad = useRef<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setAuthLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setAuthLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      const loadData = async () => {
        try {
          const [clientsData, pisData, interactionsData] = await Promise.all([
            supabaseService.getClients(user.id),
            supabaseService.getPIs(user.id),
            supabaseService.getInteractions(user.id)
          ]);
          setSavedClients(clientsData);
          setPis(pisData);
          setInteractions(interactionsData);
        } catch (error) {
          console.error("Erro ao carregar dados do Supabase:", error);
        }
      };
      loadData();
    } else {
      setSavedClients([]);
      setPis([]);
      setInteractions([]);
    }
  }, [user]);

  const handleLogin = async (provider: 'google' | 'github') => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
    } catch (error) {
      console.error(`Erro ao fazer login com ${provider}:`, error);
    }
  };

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  const saveCurrentClient = async () => {
    if (!user) {
      console.warn("Usuário não autenticado. O cliente não será salvo.");
      return;
    }
    if (!clientData.razaoSocial || !clientData.documento) {
      console.warn("Razão Social ou Documento ausentes. O cliente não será salvo.");
      return;
    }

    try {
      setIsSaving(true);
      
      await supabaseService.saveClient({
        razao_social: clientData.razaoSocial,
        nome_fantasia: clientData.nomeFantasia,
        documento: clientData.documento,
        endereco: clientData.endereco,
        cep: clientData.cep,
        inscricao_estadual: clientData.inscricaoEstadual,
        contato1: clientData.contato1,
        contato2: clientData.contato2,
        email1: clientData.email1,
        email2: clientData.email2,
        emissora: clientData.emissora,
        tipo_grade: clientData.tipoGrade,
        grade_horarios: clientData.gradeHorarios,
        dia_pagamento: clientData.diaPagamento,
        desconto: Number(clientData.desconto),
      }, user.id);

      setShowSaveSuccess(true);
      setTimeout(() => setShowSaveSuccess(false), 3000);
      
      // Refresh clients list
      const clientsData = await supabaseService.getClients(user.id);
      setSavedClients(clientsData);
      
      console.log("Cliente salvo com sucesso!");
    } catch (error) {
      console.error("Erro ao salvar cliente:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const deleteClient = async (id: string) => {
    if (!confirm("Deseja realmente excluir este cliente?")) return;
    try {
      await supabaseService.deleteClient(id);
      setSavedClients(prev => prev.filter(c => c.id !== id));
    } catch (error) {
      console.error("Erro ao excluir cliente:", error);
    }
  };

  const saveInteraction = async () => {
    if (!user || !newInteraction.clientId || !newInteraction.description) return;
    try {
      await supabaseService.saveInteraction({
        client_id: newInteraction.clientId,
        type: newInteraction.type,
        description: newInteraction.description,
        date: new Date(newInteraction.date).toISOString(),
      }, user.id);

      setShowInteractionModal(false);
      setNewInteraction({
        clientId: '',
        type: 'NOTE',
        description: '',
        date: format(new Date(), 'yyyy-MM-dd')
      });
      
      // Refresh interactions
      const interactionsData = await supabaseService.getInteractions(user.id);
      setInteractions(interactionsData);
    } catch (error) {
      console.error("Erro ao salvar interação:", error);
    }
  };

  const loadClient = (client: any) => {
    setClientData(prev => ({
      ...prev,
      razaoSocial: client.razaoSocial || '',
      nomeFantasia: client.nomeFantasia || '',
      documento: client.documento || '',
      endereco: client.endereco || '',
      cep: client.cep || '',
      inscricaoEstadual: client.inscricaoEstadual || '',
      contato1: client.contato1 || '',
      contato2: client.contato2 || '',
      email1: client.email1 || '',
      email2: client.email2 || '',
      emissora: client.emissora || '',
      tipoGrade: client.tipoGrade || 'DETERMINADO',
      gradeHorarios: client.gradeHorarios || '',
      diaPagamento: client.diaPagamento || '',
      desconto: String(client.desconto || '0'),
    }));
    setShowClientList(false);
  };

  const getVigenciaDays = () => {
    if (!clientData.dataInicio || !clientData.dataFim) return 1;
    try {
      const start = parseISO(clientData.dataInicio);
      const end = parseISO(clientData.dataFim);
      const days = differenceInDays(end, start) + 1;
      return days > 0 ? days : 1;
    } catch (e) {
      return 1;
    }
  };

  const getVigenciaMonths = () => {
    const days = getVigenciaDays();
    return Math.max(1, Math.ceil(days / 30));
  };

  const calculateProductTotal = (p: Produto) => {
    const unitValue = Number(p.valorUnitario) || 0;
    const qty = Number(p.quantidade) || 0;
    const base = unitValue * qty;
    
    if (p.periodicidade === 'DIARIO') {
      return base * getVigenciaDays();
    }
    
    // For SEMANAL and MENSAL, we'll keep it as base for now unless specified otherwise, 
    // but the user said "taking into account periodicity", so maybe:
    if (p.periodicidade === 'SEMANAL') {
      const weeks = Math.ceil(getVigenciaDays() / 7);
      return base * weeks;
    }
    
    if (p.periodicidade === 'MENSAL') {
      const months = Math.ceil(getVigenciaDays() / 30);
      return base * months;
    }

    return base;
  };

  const valorBruto = clientData.produtos.reduce((acc, curr) => {
    return acc + calculateProductTotal(curr);
  }, 0);

  const valorDesconto = (valorBruto * (Number(clientData.desconto) || 0)) / 100;
  const valorTotal = valorBruto - valorDesconto;
  const numParcelas = getVigenciaMonths();
  const valorParcela = valorTotal / numParcelas;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    let processedValue = value;
    if (name === 'documento') {
      const digits = value.replace(/\D/g, '');
      if (digits.length <= 11) {
        // CPF mask: 000.000.000-00
        processedValue = digits
          .replace(/(\d{3})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d{1,2})/, '$1-$2')
          .replace(/(-\d{2})\d+?$/, '$1');
      } else {
        // CNPJ mask: 00.000.000/0000-00
        processedValue = digits
          .replace(/(\d{2})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d)/, '$1/$2')
          .replace(/(\d{4})(\d{1,2})/, '$1-$2')
          .replace(/(-\d{2})\d+?$/, '$1');
      }
    } else if (name === 'cep') {
      processedValue = value.replace(/\D/g, '').replace(/(\d{5})(\d)/, '$1-$2').replace(/(-\d{3})\d+?$/, '$1');
    } else if (name === 'contato1' || name === 'contato2') {
      const digits = value.replace(/\D/g, '');
      processedValue = digits
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .replace(/(-\d{4})\d+?$/, '$1');
    }

    setClientData(prev => ({ ...prev, [name]: processedValue }));
    if (name === 'documento') setCnpjError(null);
    setIsGenerated(false);
  };

  const handleProductChange = (id: string, field: keyof Produto, value: string) => {
    setClientData(prev => ({
      ...prev,
      produtos: prev.produtos.map(p => p.id === id ? { ...p, [field]: value } : p)
    }));
    setIsGenerated(false);
  };

  const addProduct = () => {
    setClientData(prev => ({
      ...prev,
      produtos: [...prev.produtos, { id: crypto.randomUUID(), tipo: '', periodicidade: '', quantidade: '', valorUnitario: '' }]
    }));
  };

  const removeProduct = (id: string) => {
    if (clientData.produtos.length === 1) return;
    setClientData(prev => ({
      ...prev,
      produtos: prev.produtos.filter(p => p.id !== id)
    }));
    setIsGenerated(false);
  };

  const handleCepBlur = async () => {
    const cep = clientData.cep.replace(/\D/g, '');
    if (cep.length !== 8) return;

    setLoadingCep(true);
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setClientData(prev => ({
          ...prev,
          endereco: `${data.logradouro}, ${data.bairro}, ${data.localidade} - ${data.uf}`
        }));
      }
    } catch (error) {
      console.error("Erro ao buscar CEP:", error);
    } finally {
      setLoadingCep(false);
    }
  };

  const handleCnpjBlur = async () => {
    const cnpj = clientData.documento.replace(/\D/g, '');
    if (cnpj.length !== 14) return;

    setLoadingCnpj(true);
    setCnpjError(null);
    try {
      const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`);
      
      if (response.ok) {
        const data = await response.json();
        setClientData(prev => ({
          ...prev,
          razaoSocial: data.razao_social || prev.razaoSocial,
          nomeFantasia: data.nome_fantasia || prev.nomeFantasia,
          endereco: data.logradouro ? `${data.logradouro}, ${data.numero}${data.complemento ? ' ' + data.complemento : ''}, ${data.bairro}, ${data.municipio} - ${data.uf}` : prev.endereco,
          cep: data.cep || prev.cep
        }));
      } else {
        setCnpjError("CNPJ não encontrado ou erro na busca.");
      }
    } catch (error) {
      console.error("Erro ao buscar CNPJ:", error);
      setCnpjError("Erro ao conectar com o serviço de busca.");
    } finally {
      setLoadingCnpj(false);
    }
  };

  const generatePDF = async () => {
    const doc = new jsPDF('l', 'mm', 'a4');
    const today = format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
    const pageWidth = 297;
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);

    // Header - Fundação Santo Antônio (CONTRATADA)
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setFillColor(240, 240, 240);
    doc.rect(margin, 10, contentWidth, 5, 'F');
    doc.text('CONTRATADA (DADOS DA FUNDAÇÃO)', margin + 2, 13.5);

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Razão Social: ${FIXED_DATA.razaoSocial}`, margin + 35, 20);
    const enderecoLines = doc.splitTextToSize(FIXED_DATA.endereco, contentWidth - 40);
    doc.text(enderecoLines, margin + 35, 24);
    doc.text(`CNPJ: ${FIXED_DATA.cnpj} | IE: ${FIXED_DATA.inscricaoEstadual}`, margin + 35, 30);
    
    doc.setLineWidth(0.3);
    doc.line(margin, 32, pageWidth - margin, 32);

    // PI Title
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('PEDIDO DE INSERÇÃO (PI)', pageWidth / 2, 38, { align: 'center' });

    // Client Section (CONTRATANTE)
    doc.setFontSize(8);
    doc.setFillColor(240, 240, 240);
    doc.rect(margin, 42, contentWidth, 5, 'F');
    doc.text('CONTRATANTE (DADOS DO CLIENTE)', margin + 2, 45.5);

    doc.setFont('helvetica', 'normal');
    doc.text(`Razão Social: ${clientData.razaoSocial}`, margin, 52);
    doc.text(`Nome Fantasia: ${clientData.nomeFantasia}`, margin + 140, 52);
    doc.text(`CNPJ/CPF: ${clientData.documento}`, margin, 56);
    doc.text(`Inscrição Estadual: ${clientData.inscricaoEstadual}`, margin + 70, 56);
    doc.text(`CEP: ${clientData.cep}`, margin + 140, 56);
    doc.text(`Endereço: ${clientData.endereco}`, margin, 60);
    doc.text(`Celulares: ${clientData.contato1} / ${clientData.contato2}`, margin, 64);
    doc.text(`E-mails: ${clientData.email1} / ${clientData.email2}`, margin + 140, 64);

    // Campaign Section
    doc.setFont('helvetica', 'bold');
    doc.setFillColor(240, 240, 240);
    doc.rect(margin, 68, contentWidth, 5, 'F');
    doc.text('DETALHES DA CAMPANHA', margin + 2, 71.5);

    const formatDate = (dateStr: string) => {
      try {
        return format(parseISO(dateStr), 'dd/MM/yyyy');
      } catch (e) {
        return dateStr;
      }
    };

    doc.setFont('helvetica', 'normal');
    doc.text(`Emissora: ${clientData.emissora}`, margin, 78);
    doc.text(`Período: ${formatDate(clientData.dataInicio)} até ${formatDate(clientData.dataFim)}`, margin + 70, 78);
    doc.text(`Tipo de Grade: ${clientData.tipoGrade}`, margin + 140, 78);
    
    const gradeText = clientData.tipoGrade === 'DETERMINADO' 
      ? `Horários Fixos: ${clientData.gradeHorarios}` 
      : 'Horário: Rotativo ao longo da programação';
    doc.text(gradeText, margin, 82);

    const formatPaymentDate = () => {
      if (!clientData.diaPagamento || !clientData.dataInicio) return '-';
      try {
        const start = parseISO(clientData.dataInicio);
        const months = getVigenciaMonths();
        const dayNum = parseInt(clientData.diaPagamento);
        const dates = [];
        
        for (let i = 0; i < months; i++) {
          let date = addMonths(start, i);
          date = setDate(date, dayNum);
          dates.push(format(date, 'dd/MM/yyyy'));
        }
        return dates.join(', ');
      } catch (e) {
        return `Dia ${clientData.diaPagamento}`;
      }
    };

    // Table
    const tableHead = [['Descrição', 'Periodicidade', 'Qtd', 'Vlr. Unitário', 'Data Pagto', 'Total']];
    const tableBody = clientData.produtos.map(p => [
      `Veiculação Publicitária - ${p.tipo}`, 
      p.periodicidade,
      p.quantidade, 
      `R$ ${Number(p.valorUnitario).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 
      formatPaymentDate(),
      `R$ ${calculateProductTotal(p).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
    ]);

    autoTable(doc, {
      startY: 88,
      head: tableHead,
      body: tableBody,
      theme: 'grid',
      headStyles: { fillColor: [40, 40, 40], textColor: [255, 255, 255], fontSize: 8, cellPadding: 1 },
      bodyStyles: { fontSize: 8, cellPadding: 1 },
      margin: { left: margin, right: margin }
    });

    // Totals
    const finalY = (doc as any).lastAutoTable.finalY + 5;
    const rightAlignX = pageWidth - margin;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Valor Bruto: R$ ${valorBruto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, rightAlignX, finalY, { align: 'right' });
    doc.text(`Desconto (${clientData.desconto}%): R$ ${valorDesconto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, rightAlignX, finalY + 4, { align: 'right' });
    
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text(`VALOR TOTAL LÍQUIDO: R$ ${valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, rightAlignX, finalY + 10, { align: 'right' });

    if (numParcelas > 1) {
      doc.setFontSize(8);
      doc.setFont('helvetica', 'italic');
      doc.text(`Condição de Pagamento: ${numParcelas} parcelas mensais de R$ ${valorParcela.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, rightAlignX, finalY + 14, { align: 'right' });
    }

    // Signature
    const sigY = finalY + 25;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Feira de Santana/BA, ${today}`, margin, sigY);

    // Signature Line and Label
    const lineY = sigY + 15;
    const centerX = pageWidth / 2;
    doc.setLineWidth(0.2);
    doc.line(centerX - 45, lineY, centerX + 45, lineY);
    doc.setFontSize(8);
    doc.text('Assinatura e Carimbo do Cliente', centerX, lineY + 4, { align: 'center' });

    // Signature Image
    if (sigPad.current && !sigPad.current.isEmpty()) {
      try {
        const sigImage = sigPad.current.getCanvas().toDataURL('image/png');
        doc.addImage(sigImage, 'PNG', centerX - 45, lineY - 15, 90, 18);
      } catch (e) {
        console.error("Erro ao adicionar assinatura no PDF:", e);
      }
    }

    // Clauses below signature
    let clausesY = lineY + 12;
    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text('3. PAGAMENTO E INADIMPLÊNCIA', margin, clausesY);
    clausesY += 4;
    doc.setFont('helvetica', 'normal');
    
    const clauses = [
      '3.1. O pagamento deverá ser efetuado até a data de vencimento estipulada no PI. O atraso sujeitará a CONTRATANTE à multa moratória de 2% e juros de 1% ao mês.',
      '3.2. Cobrança e Negativação: Decorridos 15 (quinze) dias corridos do vencimento sem a devida quitação, a CONTRATADA fica autorizada a:',
      'a) Encaminhar o débito para empresa de cobrança especializada ou assessoria jurídica;',
      'b) Realizar a negativação (inscrição do CPF ou CNPJ) nos órgãos de proteção ao crédito (SPC/SERASA);',
      'c) Proceder com o protesto em cartório do título de crédito correspondente.',
      '3.3. Honorários: Em caso de cobrança extrajudicial, incidirão sobre o montante total honorários de cobrança fixados em 20% (vinte por cento), além de custas de notificação, sob responsabilidade da CONTRATANTE'
    ];

    clauses.forEach(text => {
      const lines = doc.splitTextToSize(text, pageWidth - (margin * 2));
      doc.text(lines, margin, clausesY);
      clausesY += (lines.length * 3.5);
    });

    await saveCurrentClient();
    doc.save(`PI_${clientData.razaoSocial.replace(/\s+/g, '_')}.pdf`);
  };

  const generateContractPDF = async () => {
    const doc = new jsPDF('p', 'mm', 'a4');
    const today = format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
    const margin = 20;
    const pageWidth = 210;
    const pageHeight = 297;
    const contentWidth = pageWidth - (margin * 2);
    const bottomMargin = 30;

    let y = 20;

    const checkPageBreak = (neededHeight: number) => {
      if (y + neededHeight > pageHeight - bottomMargin) {
        doc.addPage();
        y = 20;
        return true;
      }
      return false;
    };

    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('TERMOS E CONDIÇÕES DE PRESTAÇÃO DE SERVIÇOS DE RADIODIFUSÃO', pageWidth / 2, y, { align: 'center' });
    y += 15;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    // CONTRATADA
    doc.setFont('helvetica', 'bold');
    doc.text('CONTRATADA:', margin, y);
    doc.setFont('helvetica', 'normal');
    const contratadaText = 'FUNDAÇÃO SANTO ANTÔNIO, com sede na Rua Frei Hermenegildo Castorano, 300, Capuchinhos, Feira de Santana/BA, CEP 44.076-170, inscrita no CNPJ sob o nº 63.104.830/0001-89 e Inscrição Estadual nº 86.287.045.';
    const contratadaLines = doc.splitTextToSize(contratadaText, contentWidth - 30);
    doc.text(contratadaLines, margin + 30, y);
    y += (contratadaLines.length * 5) + 5;

    // CONTRATANTE
    checkPageBreak(20);
    doc.setFont('helvetica', 'bold');
    doc.text('CONTRATANTE:', margin, y);
    doc.setFont('helvetica', 'normal');
    const contratanteText = `${clientData.razaoSocial}, inscrita no CNPJ/CPF sob o nº ${clientData.documento}, com sede em ${clientData.endereco}, CEP ${clientData.cep}, qualificada no Pedido de Inserção (PI) anexo, que é parte integrante e indissociável deste instrumento.`;
    const contratanteLines = doc.splitTextToSize(contratanteText, contentWidth - 30);
    doc.text(contratanteLines, margin + 30, y);
    y += (contratanteLines.length * 5) + 10;

    const sections = [
      {
        title: '1. OBJETO E VEICULAÇÃO',
        content: [
          '1.1. A CONTRATADA compromete-se a veicular o material publicitário da CONTRATANTE conforme as especificações de datas, horários, programas e quantidades descritas no PI.',
          '1.2. Entrega do Material: O material (spot, vinheta ou texto) deve ser entregue com antecedência mínima de 24/48 (vinte e quatro e/ou quarenta e oito ) horas úteis à primeira veiculação, em formato digital compatível (MP3 ou WAV).',
          '1.3. Comprovação: A CONTRATADA fornecerá, mediante solicitação, o Comprovante de Irradiação (Checking), que atesta o cumprimento fiel do plano de mídia contratado.'
        ]
      },
      {
        title: '2. ALTERAÇÕES E CANCELAMENTOS',
        content: [
          '2.1. Pedidos de alteração no cronograma devem ser feitos por escrito com no mínimo 48 (quarenta e oito) horas de antecedência.',
          '2.2. Rescisão: O cancelamento do contrato após o início das veiculações implicará no pagamento dos serviços já realizados, acrescido de uma multa de 20% (vinte por cento) sobre o saldo remanescente.'
        ]
      },
      {
        title: '3. PAGAMENTO E INADIMPLÊNCIA',
        content: [
          '3.1. O pagamento deverá ser efetuado até a data de vencimento estipulada no PI. O atraso sujeitará a CONTRATANTE à multa moratória de 2% e juros de 1% ao mês.',
          '3.2. Cobrança e Negativação: Decorridos 15 (quinze) dias corridos do vencimento sem a devida quitação, a CONTRATADA fica autorizada a:',
          'a) Encaminhar o débito para empresa de cobrança especializada ou assessoria jurídica;',
          'b) Realizar a negativação (inscrição do CPF ou CNPJ) nos órgãos de proteção ao crédito (SPC/SERASA);',
          'c) Proceder com o protesto em cartório do título de crédito correspondente.',
          '3.3. Honorários: Em caso de cobrança extrajudicial, incidirão sobre o montante total honorários de cobrança fixados em 20% (vinte por cento), além de custas de notificação, sob responsabilidade da CONTRATANTE.'
        ]
      },
      {
        title: '4. RESPONSABILIDADE E ÉTICA',
        content: [
          '4.1. A CONTRATANTE assume total responsabilidade civil e criminal pelo conteúdo da publicidade (direitos autorais, marcas e veracidade), isentando a FUNDAÇÃO SANTO ANTÔNIO de qualquer litígio.',
          '4.2. A CONTRATADA reserva-se o direito de recusar conteúdos que infrinjam a legislação, a ética ou as normas do CENP.'
        ]
      },
      {
        title: '5. FORO',
        content: [
          '5.1. Fica eleito o Foro da Comarca de Feira de Santana/BA para dirimir quaisquer controvérsias oriundas deste contrato.'
        ]
      }
    ];

    sections.forEach(section => {
      checkPageBreak(10);
      doc.setFont('helvetica', 'bold');
      doc.text(section.title, margin, y);
      y += 6;
      doc.setFont('helvetica', 'normal');
      section.content.forEach(text => {
        const lines = doc.splitTextToSize(text, contentWidth);
        checkPageBreak(lines.length * 5);
        doc.text(lines, margin, y);
        y += (lines.length * 5) + 2;
      });
      y += 3;
    });

    checkPageBreak(50);
    y += 10;
    doc.text(`Feira de Santana/BA, ${today}`, margin, y);
    
    y += 30;
    const centerX = pageWidth / 2;
    doc.setLineWidth(0.2);
    doc.line(centerX - 45, y, centerX + 45, y);
    doc.setFontSize(9);
    doc.text('Assinatura e Carimbo do Cliente', centerX, y + 5, { align: 'center' });

    if (sigPad.current && !sigPad.current.isEmpty()) {
      try {
        const sigImage = sigPad.current.getCanvas().toDataURL('image/png');
        doc.addImage(sigImage, 'PNG', centerX - 45, y - 18, 90, 20);
      } catch (e) {
        console.error("Erro ao adicionar assinatura no contrato:", e);
      }
    }

    await saveCurrentClient();
    doc.save(`Contrato_${clientData.razaoSocial.replace(/\s+/g, '_')}.pdf`);
  };

  const generateExcel = async () => {
    const formatDate = (dateStr: string) => {
      try {
        return format(parseISO(dateStr), 'dd/MM/yyyy');
      } catch (e) {
        return dateStr;
      }
    };

    const formatPaymentDateExcel = () => {
      if (!clientData.diaPagamento || !clientData.dataInicio) return '-';
      try {
        const start = parseISO(clientData.dataInicio);
        const months = getVigenciaMonths();
        const dayNum = parseInt(clientData.diaPagamento);
        const dates = [];
        
        for (let i = 0; i < months; i++) {
          let date = addMonths(start, i);
          date = setDate(date, dayNum);
          dates.push(format(date, 'dd/MM/yyyy'));
        }
        return dates.join(', ');
      } catch (e) {
        return clientData.diaPagamento;
      }
    };

    const wsData = [
      ["EMISSORA", "RAZÃO SOCIAL", "NOME FANTASIA", "CNPJ/CPF", "ENDEREÇO", "CEP", "INSC. ESTADUAL", "CELULAR 1", "CELULAR 2", "E-MAIL 1", "E-MAIL 2", "PRODUTO", "PERIODICIDADE", "INÍCIO", "FIM", "TIPO GRADE", "HORÁRIOS", "QTD", "VLR UNIT", "DATA PAGAMENTO", "VLR TOTAL ITEM", "DESCONTO %", "VALOR LÍQUIDO TOTAL", "QTD PARCELAS", "VALOR PARCELA", "DATA GERAÇÃO"],
      ...clientData.produtos.map((p, index) => [
        clientData.emissora,
        clientData.razaoSocial,
        clientData.nomeFantasia,
        clientData.documento,
        clientData.endereco,
        clientData.cep,
        clientData.inscricaoEstadual,
        clientData.contato1,
        clientData.contato2,
        clientData.email1,
        clientData.email2,
        p.tipo,
        p.periodicidade,
        formatDate(clientData.dataInicio),
        formatDate(clientData.dataFim),
        clientData.tipoGrade,
        clientData.tipoGrade === 'DETERMINADO' ? clientData.gradeHorarios : 'ROTATIVO',
        p.quantidade,
        p.valorUnitario,
        formatPaymentDateExcel(),
        calculateProductTotal(p),
        index === 0 ? clientData.desconto : "",
        index === 0 ? valorTotal : "",
        index === 0 ? numParcelas : "",
        index === 0 ? valorParcela : "",
        format(new Date(), "dd/MM/yyyy HH:mm")
      ])
    ];

    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Controle de Tráfego");
    await saveCurrentClient();
    XLSX.writeFile(wb, `Controle_${clientData.razaoSocial.replace(/\s+/g, '_')}.xlsx`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveCurrentClient();
    
    // Save PI record for CRM history
    if (user) {
      try {
        await supabaseService.savePI({
          client_name: clientData.razaoSocial,
          emissora: clientData.emissora,
          data_inicio: clientData.dataInicio,
          data_fim: clientData.dataFim,
          dia_pagamento: clientData.diaPagamento,
          valor_total: valorTotal,
          status: 'SENT',
        }, user.id);
        
        // Refresh PIs
        const pisData = await supabaseService.getPIs(user.id);
        setPis(pisData);
      } catch (error) {
        console.error("Erro ao salvar histórico de PI:", error);
      }
    }

    setIsGenerated(true);
    await generatePDF();
  };

  const isFormValid = 
    clientData.razaoSocial && 
    clientData.documento && 
    clientData.contato1 &&
    clientData.contato2 &&
    clientData.email1 &&
    clientData.email2 &&
    clientData.dataInicio && 
    clientData.dataFim && 
    clientData.emissora &&
    clientData.produtos.every(p => p.tipo && p.periodicidade && p.quantidade && p.valorUnitario);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthView onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#fcfcfc] text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* Auth & Navigation Bar */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-center gap-6 mb-12"
        >
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200">
              <Building2 className="text-white" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display tracking-tight">Portal de Operações</h2>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">REDE DE RADIO COMUNICAÇÃO</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">
            {user && (
              <div className="flex bg-slate-100 p-1 rounded-2xl">
                <button
                  onClick={() => setView('dashboard')}
                  className={cn(
                    "flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all",
                    view === 'dashboard' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  <LayoutDashboard size={16} />
                  Dashboard
                </button>
                <button
                  onClick={() => setView('pi-generator')}
                  className={cn(
                    "flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all",
                    view === 'pi-generator' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  <Plus size={16} />
                  Novo PI
                </button>
                <button
                  onClick={() => setView('clients')}
                  className={cn(
                    "flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all",
                    view === 'clients' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  <Users size={16} />
                  Clientes
                </button>
              </div>
            )}

            {user ? (
              <div className="flex items-center gap-3 bg-white p-1.5 pr-4 rounded-2xl shadow-sm border border-slate-200">
                {user.user_metadata?.avatar_url ? (
                  <img src={user.user_metadata.avatar_url} alt={user.user_metadata.full_name || 'Usuário'} className="w-9 h-9 rounded-xl shadow-sm" />
                ) : (
                  <div className="w-9 h-9 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                    {(user.user_metadata?.full_name || user.email || 'U').charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="hidden sm:block">
                  <p className="text-xs font-bold leading-none mb-0.5">{user.user_metadata?.full_name || user.email?.split('@')[0]}</p>
                  <button 
                    onClick={handleLogout}
                    className="text-[10px] font-bold text-slate-400 hover:text-rose-500 transition-colors uppercase tracking-widest"
                  >
                    Sair
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={() => handleLogin('google')}
                className="flex items-center gap-2 bg-white px-6 py-3 rounded-2xl shadow-sm border border-slate-200 hover:bg-slate-50 transition-all text-sm font-bold"
              >
                <LogIn size={18} className="text-indigo-600" />
                Acessar com Google
              </button>
            )}
          </div>
        </motion.div>

        {/* Main Content Area */}
        <main>
          <AnimatePresence mode="wait">
            {view === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <DashboardView 
                  pis={pis} 
                  clients={savedClients} 
                  interactions={interactions} 
                  onNewPI={() => setView('pi-generator')}
                  onAddInteraction={() => setShowInteractionModal(true)}
                />
              </motion.div>
            )}

            {view === 'clients' && (
              <motion.div
                key="clients"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <ClientsView 
                  clients={savedClients} 
                  onLoadClient={(c: any) => { loadClient(c); setView('pi-generator'); }}
                  onDeleteClient={deleteClient}
                />
              </motion.div>
            )}

            {view === 'pi-generator' && (
              <motion.div
                key="pi-generator"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-12"
              >
                {/* Header Fixed Data */}
                <header className="glass-card rounded-[2.5rem] p-8 md:p-10">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
                    <div className="flex items-center gap-6">
                      <div className="h-20 w-20 bg-indigo-50 rounded-[2rem] flex items-center justify-center border border-indigo-100/50 shadow-inner">
                        <Building2 className="text-indigo-600" size={32} />
                      </div>
                      <div>
                        <h1 className="text-3xl font-black font-display tracking-tight text-slate-900 leading-tight">
                          {FIXED_DATA.razaoSocial}
                        </h1>
                        <p className="text-sm text-slate-500 font-medium mt-1 max-w-md leading-relaxed">
                          {FIXED_DATA.endereco}
                        </p>
                      </div>
                    </div>
                    <div className="bg-slate-900/5 backdrop-blur-sm px-6 py-5 rounded-[2rem] border border-slate-200/50 min-w-[240px]">
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-600 mb-3">Informações Fiscais</p>
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center gap-4">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">CNPJ</span>
                          <span className="text-xs font-mono font-bold text-slate-700">{FIXED_DATA.cnpj}</span>
                        </div>
                        <div className="flex justify-between items-center gap-4">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">Inscrição</span>
                          <span className="text-xs font-mono font-bold text-slate-700">{FIXED_DATA.inscricaoEstadual}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
                  <section className="lg:col-span-8">
                    <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-200 p-8 md:p-12">
                      <div className="flex items-center gap-4 mb-12">
                        <div className="p-3 bg-indigo-50 rounded-2xl">
                          <Plus className="w-6 h-6 text-indigo-600" />
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold font-display tracking-tight">Novo Pedido de Inserção</h2>
                          <p className="text-sm text-slate-500 font-medium">Preencha os dados para gerar os documentos</p>
                        </div>
                      </div>

                      <form onSubmit={handleSubmit} className="space-y-12">
                        {/* Seção Cliente */}
                        <div className="space-y-8">
                          <div className="flex items-center gap-3">
                            <span className="h-px flex-1 bg-slate-100" />
                            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Identificação do Cliente</h3>
                            <span className="h-px flex-1 bg-slate-100" />
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Razão Social</label>
                      <input
                        required
                        name="razaoSocial"
                        value={clientData.razaoSocial}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Nome completo da empresa"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Nome Fantasia</label>
                      <input
                        name="nomeFantasia"
                        value={clientData.nomeFantasia}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Como a empresa é conhecida"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">CNPJ ou CPF</label>
                      <div className="relative">
                        <input
                          required
                          name="documento"
                          value={clientData.documento}
                          onChange={handleInputChange}
                          onBlur={handleCnpjBlur}
                          placeholder="00.000.000/0001-00"
                          className="input-field"
                        />
                        {loadingCnpj && (
                          <div className="absolute right-4 top-1/2 -translate-y-1/2">
                            <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                          </div>
                        )}
                      </div>
                      {cnpjError && (
                        <p className="text-[10px] text-rose-500 font-bold ml-1 mt-1 flex items-center gap-1">
                          <AlertCircle size={12} />
                          {cnpjError}
                        </p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Inscrição Estadual</label>
                      <input
                        name="inscricaoEstadual"
                        value={clientData.inscricaoEstadual}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Ou 'Isento'"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Celular Principal</label>
                      <input
                        required
                        name="contato1"
                        value={clientData.contato1}
                        onChange={handleInputChange}
                        placeholder="(00) 00000-0000"
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Celular Secundário</label>
                      <input
                        required
                        name="contato2"
                        value={clientData.contato2}
                        onChange={handleInputChange}
                        placeholder="(00) 00000-0000"
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">E-mail Principal</label>
                      <input
                        required
                        type="email"
                        name="email1"
                        value={clientData.email1}
                        onChange={handleInputChange}
                        placeholder="email@exemplo.com"
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">E-mail Secundário</label>
                      <input
                        required
                        type="email"
                        name="email2"
                        value={clientData.email2}
                        onChange={handleInputChange}
                        placeholder="email2@exemplo.com"
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Endereço Completo</label>
                      <input
                        required
                        name="endereco"
                        value={clientData.endereco}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Rua, número, bairro, cidade - UF"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">CEP</label>
                      <div className="relative">
                        <input
                          name="cep"
                          value={clientData.cep}
                          onChange={handleInputChange}
                          onBlur={handleCepBlur}
                          placeholder="00000-000"
                          className="input-field"
                        />
                        {loadingCep && (
                          <div className="absolute right-4 top-1/2 -translate-y-1/2">
                            <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Seção Campanha */}
                <div className="space-y-8">
                  <div className="flex items-center gap-3">
                    <span className="h-px flex-1 bg-slate-100" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Detalhes da Veiculação</h3>
                    <span className="h-px flex-1 bg-slate-100" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2 md:col-span-3">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Emissora</label>
                      <select
                        required
                        name="emissora"
                        value={clientData.emissora}
                        onChange={handleInputChange}
                        className="input-field appearance-none"
                      >
                        <option value="">Selecione uma emissora</option>
                        <option value="SOCIEDADE NEWS">SOCIEDADE NEWS</option>
                        <option value="PRINCESA FM">PRINCESA FM</option>
                        <option value="INTERATIVA FM">INTERATIVA FM</option>
                        <option value="CARAIBA FM">CARAIBA FM</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Data de Início</label>
                      <input
                        required
                        type="date"
                        name="dataInicio"
                        value={clientData.dataInicio}
                        onChange={handleInputChange}
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Data de Término</label>
                      <input
                        required
                        type="date"
                        name="dataFim"
                        value={clientData.dataFim}
                        onChange={handleInputChange}
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Dia Pagto</label>
                      <input
                        required
                        type="number"
                        min="1"
                        max="31"
                        name="diaPagamento"
                        value={clientData.diaPagamento}
                        onChange={handleInputChange}
                        placeholder="Ex: 10"
                        className="input-field"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Grade de Horário</label>
                      <select
                        name="tipoGrade"
                        value={clientData.tipoGrade}
                        onChange={handleInputChange}
                        className="input-field appearance-none"
                      >
                        <option value="DETERMINADO">DETERMINADO (Fixos)</option>
                        <option value="INDETERMINADO">INDETERMINADO (Rotativo)</option>
                      </select>
                    </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Horários (Se Determinado)</label>
                        <input
                          name="gradeHorarios"
                          value={clientData.gradeHorarios}
                          onChange={handleInputChange}
                          placeholder="Ex: 08h, 12h, 18h"
                          className="input-field disabled:opacity-40 disabled:bg-slate-100"
                        />
                      </div>
                  </div>
                </div>

                {/* Seção Produtos */}
                <div className="space-y-8">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="h-px w-8 bg-slate-100" />
                      <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Produtos e Valores</h3>
                    </div>
                    <button
                      type="button"
                      onClick={addProduct}
                      className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-700 transition-colors bg-indigo-50 px-4 py-2 rounded-xl"
                    >
                      <Plus size={14} />
                      Adicionar Item
                    </button>
                  </div>
                  
                  <div className="space-y-6">
                    <AnimatePresence mode="popLayout">
                      {clientData.produtos.map((produto, index) => (
                        <motion.div 
                          layout
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          key={produto.id} 
                          className="p-8 bg-slate-50/50 rounded-[2rem] border border-slate-100 relative group hover:bg-white hover:shadow-xl hover:shadow-slate-200/30 transition-all duration-300"
                        >
                          <div className="absolute -left-3 top-8 w-6 h-6 bg-white border border-slate-200 rounded-lg flex items-center justify-center text-[10px] font-black text-slate-400 shadow-sm">
                            {index + 1}
                          </div>

                          {clientData.produtos.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeProduct(produto.id)}
                              className="absolute -top-3 -right-3 p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-rose-500 hover:border-rose-200 shadow-lg transition-all opacity-0 group-hover:opacity-100 z-10"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                            <div className="md:col-span-3 space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Tipo</label>
                              <select
                                required
                                value={produto.tipo}
                                onChange={(e) => handleProductChange(produto.id, 'tipo', e.target.value)}
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium appearance-none"
                              >
                                <option value="">Selecione</option>
                                <option value="SPOT">SPOT</option>
                                <option value="TESTEMUNHAL">TESTEMUNHAL</option>
                                <option value="BLITZ">BLITZ</option>
                              </select>
                            </div>
                            <div className="md:col-span-3 space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Periodicidade</label>
                              <select
                                required
                                value={produto.periodicidade}
                                onChange={(e) => handleProductChange(produto.id, 'periodicidade', e.target.value)}
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium appearance-none"
                              >
                                <option value="">Selecione</option>
                                <option value="DIARIO">DIÁRIO</option>
                                <option value="SEMANAL">SEMANAL</option>
                                <option value="MENSAL">MENSAL</option>
                              </select>
                            </div>
                            <div className="md:col-span-3 space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Qtd</label>
                              <input
                                required
                                type="number"
                                value={produto.quantidade}
                                onChange={(e) => handleProductChange(produto.id, 'quantidade', e.target.value)}
                                placeholder="0"
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                              />
                            </div>
                            <div className="md:col-span-3 space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Valor Unit.</label>
                              <input
                                required
                                type="number"
                                step="0.01"
                                value={produto.valorUnitario}
                                onChange={(e) => handleProductChange(produto.id, 'valorUnitario', e.target.value)}
                                placeholder="0,00"
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                              />
                            </div>
                          </div>
                          <div className="mt-6 pt-6 border-t border-slate-100 flex justify-between items-center">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Subtotal do Item</span>
                            <div className="text-right">
                              <span className="text-sm font-black text-slate-900">
                                R$ {calculateProductTotal(produto).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                              </span>
                              {produto.periodicidade === 'DIARIO' && clientData.dataInicio && clientData.dataFim && (
                                <p className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider mt-0.5">
                                  Calculado para {getVigenciaDays()} dias
                                </p>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                </div>

                <motion.div 
                  layout
                  className="p-10 bg-slate-900 rounded-[2.5rem] flex flex-col md:flex-row justify-between items-center gap-8 shadow-2xl shadow-slate-900/20 relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -mr-32 -mt-32 blur-3xl" />
                  
                  <div className="flex flex-col md:flex-row items-center gap-12 w-full md:w-auto relative z-10">
                    <div className="w-full md:w-40">
                      <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2 block">Desconto (%)</label>
                      <div className="relative">
                        <input
                          type="number"
                          name="desconto"
                          value={clientData.desconto}
                          onChange={handleInputChange}
                          placeholder="0"
                          min="0"
                          max="100"
                          className="w-full px-4 py-3 bg-white/10 border border-white/10 rounded-2xl text-white focus:ring-4 focus:ring-indigo-500/30 outline-none transition-all font-bold text-lg"
                        />
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 font-black">%</span>
                      </div>
                    </div>
                    <div className="text-center md:text-left">
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2">Resumo Financeiro</p>
                      <div className="flex flex-col">
                        {Number(clientData.desconto) > 0 && (
                          <span className="text-sm text-slate-500 line-through font-bold mb-1">
                            R$ {valorBruto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                        )}
                        <p className="text-4xl font-black text-white tracking-tight">
                          R$ {valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                        {numParcelas > 1 && (
                          <div className="flex items-center gap-2 mt-2">
                            <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded-lg font-black uppercase tracking-wider">
                              {numParcelas} Parcelas
                            </span>
                            <span className="text-xs text-slate-400 font-bold">
                              de R$ {valorParcela.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Separator */}
                <div className="my-12 border-t-2 border-slate-100/10" />

                {/* Signature Section */}
                <div className="space-y-8">
                  <div className="flex items-center gap-3">
                    <span className="h-px w-8 bg-slate-100" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Assinatura Digital</h3>
                  </div>
                  
                  <div className="max-w-3xl mx-auto space-y-8">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Assinatura do Cliente</label>
                        <button
                          type="button"
                          onClick={() => sigPad.current?.clear()}
                          className="text-[10px] font-black uppercase tracking-widest text-rose-500 hover:text-rose-600 transition-colors"
                        >
                          Limpar Assinatura
                        </button>
                      </div>
                      <div className="bg-white border-2 border-slate-200 rounded-[2rem] overflow-hidden shadow-sm hover:border-indigo-300 transition-all">
                        <SignaturePad
                          ref={sigPad}
                          penColor="#0f172a"
                          canvasProps={{
                            className: "w-full h-48 cursor-crosshair"
                          }}
                        />
                      </div>
                      <p className="text-[10px] text-slate-400 text-center font-bold uppercase tracking-wider">
                        Assine acima usando o mouse ou tela touch
                      </p>
                    </div>

                    <div className="bg-indigo-50/50 p-8 rounded-[2.5rem] border border-indigo-100/50">
                      <div className="flex flex-col gap-8">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200 shrink-0">
                            <CheckCircle2 size={24} />
                          </div>
                          <div>
                            <h4 className="text-sm font-black text-slate-900 uppercase tracking-wider">Pronto para Gerar</h4>
                            <p className="text-xs text-slate-500 font-medium">Revise os dados antes de finalizar o documento.</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <button
                            type="submit"
                            disabled={isSaving}
                            className={cn(
                              "md:col-span-3 flex items-center justify-center gap-3 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 shadow-lg",
                              !isSaving
                                ? "bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-indigo-200"
                                : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
                            )}
                          >
                            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText size={18} />}
                            {isSaving ? "Salvando..." : "Confirmar e Gerar PI"}
                          </button>

                          <button
                            type="button"
                            onClick={saveCurrentClient}
                            disabled={isSaving}
                            className={cn(
                              "md:col-span-3 flex items-center justify-center gap-3 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 border-2",
                              !isSaving
                                ? "border-indigo-200 text-indigo-600 hover:border-indigo-600 bg-white"
                                : "border-slate-100 text-slate-300 cursor-not-allowed"
                            )}
                          >
                            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save size={18} />}
                            {isSaving ? "Salvando..." : "Salvar Apenas Cliente"}
                          </button>

                          <AnimatePresence>
                            {showSaveSuccess && (
                              <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: 10 }}
                                className="md:col-span-3 flex items-center justify-center gap-2 py-2 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-100"
                              >
                                <CheckCircle2 size={16} />
                                <span className="text-[10px] font-black uppercase tracking-widest">Cliente salvo com sucesso!</span>
                              </motion.div>
                            )}
                          </AnimatePresence>

                          <button
                            type="button"
                            onClick={generatePDF}
                            className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 border-2 border-indigo-200 text-indigo-600 hover:border-indigo-600 bg-white"
                          >
                            PI PDF
                          </button>
                          <button
                            type="button"
                            onClick={generateContractPDF}
                            className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 border-2 border-indigo-200 text-indigo-600 hover:border-indigo-600 bg-white"
                          >
                            Contrato
                          </button>
                          <button
                            type="button"
                            onClick={generateExcel}
                            className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 border-2 border-emerald-200 text-emerald-600 hover:border-emerald-600 bg-white"
                          >
                            Excel
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                      </form>
                    </div>
                  </section>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Interaction Modal */}
      <AnimatePresence>
        {showInteractionModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowInteractionModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2rem] w-full max-w-lg overflow-hidden shadow-2xl relative z-10 flex flex-col border border-slate-200"
            >
              <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h2 className="text-xl font-bold font-display tracking-tight flex items-center gap-3">
                  <MessageSquare className="text-indigo-600" size={24} />
                  Nova Interação
                </h2>
                <button onClick={() => setShowInteractionModal(false)} className="text-slate-400 hover:text-slate-600">
                  <Plus className="rotate-45" size={24} />
                </button>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Cliente</label>
                  <select 
                    value={newInteraction.clientId}
                    onChange={(e) => setNewInteraction({...newInteraction, clientId: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                  >
                    <option value="">Selecione um cliente...</option>
                    {savedClients.map(c => (
                      <option key={c.id} value={c.id}>{c.razaoSocial}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Tipo</label>
                    <select 
                      value={newInteraction.type}
                      onChange={(e) => setNewInteraction({...newInteraction, type: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                    >
                      <option value="NOTE">Nota</option>
                      <option value="CALL">Chamada</option>
                      <option value="EMAIL">E-mail</option>
                      <option value="MEETING">Reunião</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Data</label>
                    <input 
                      type="date" 
                      value={newInteraction.date}
                      onChange={(e) => setNewInteraction({...newInteraction, date: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Descrição</label>
                  <textarea 
                    rows={4}
                    value={newInteraction.description}
                    onChange={(e) => setNewInteraction({...newInteraction, description: e.target.value})}
                    placeholder="O que aconteceu nesta interação?"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all resize-none"
                  />
                </div>

                <button 
                  onClick={saveInteraction}
                  disabled={!newInteraction.clientId || !newInteraction.description}
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
                >
                  Salvar Interação
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="py-12 text-center">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">
          © 2026 REDE DE RADIO COMUNICAÇÃO • Sistema de Gestão de Publicidade
        </p>
      </footer>
    </div>
  );
}
