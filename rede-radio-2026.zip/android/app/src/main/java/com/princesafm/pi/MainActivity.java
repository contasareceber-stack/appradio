package com.princesafm.pi;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
