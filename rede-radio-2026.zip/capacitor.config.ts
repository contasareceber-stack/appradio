import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.redederadio.pi',
  appName: 'REDE DE RADIO COMUNICAÇÃO',
  webDir: 'dist'
};

export default config;
