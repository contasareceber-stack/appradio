-- Create Clients table
CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  razao_social TEXT NOT NULL,
  nome_fantasia TEXT,
  documento TEXT NOT NULL,
  endereco TEXT,
  cep TEXT,
  inscricao_estadual TEXT,
  contato1 TEXT,
  contato2 TEXT,
  email1 TEXT,
  email2 TEXT,
  emissora TEXT,
  tipo_grade TEXT,
  grade_horarios TEXT,
  dia_pagamento TEXT,
  desconto NUMERIC DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT now(),
  owner_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create PIs table
CREATE TABLE IF NOT EXISTS pis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  client_name TEXT,
  emissora TEXT,
  data_inicio DATE,
  data_fim DATE,
  dia_pagamento TEXT,
  valor_total NUMERIC NOT NULL,
  status TEXT CHECK (status IN ('DRAFT', 'SENT', 'SIGNED', 'PAID', 'CANCELLED')) DEFAULT 'DRAFT',
  owner_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create Interactions table
CREATE TABLE IF NOT EXISTS interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('CALL', 'EMAIL', 'MEETING', 'NOTE')) NOT NULL,
  description TEXT NOT NULL,
  date TIMESTAMPTZ DEFAULT now(),
  owner_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE pis ENABLE ROW LEVEL SECURITY;
ALTER TABLE interactions ENABLE ROW LEVEL SECURITY;

-- Create policies (Assuming owner_id matches the authenticated user's ID)
-- Note: In Supabase, auth.uid() returns the user's UUID. 
-- If owner_id is a string from Firebase, you might need to adjust this.

CREATE POLICY "Users can only access their own clients" ON clients
  FOR ALL USING (auth.uid()::text = owner_id);

CREATE POLICY "Users can only access their own pis" ON pis
  FOR ALL USING (auth.uid()::text = owner_id);

CREATE POLICY "Users can only access their own interactions" ON interactions
  FOR ALL USING (auth.uid()::text = owner_id);
